# SURVIVE UNTIL EARTH

**NASA Space Apps Challenge 2026 — Build a Junior Astronaut Mission Trainer**

SURVIVE UNTIL EARTH is a browser-based, 2D educational lunar mission simulator. Players explore a fictional Moon base, manage oxygen, water, food and electricity, repair equipment through minigames, encounter historical NASA DONKI-inspired space-weather scenarios, and plan a return to Earth across seven in-game days.

## Play

Open the live GitHub Pages site (once published) or open `index.html` locally in a modern browser. Use **How to Play** or the interactive training mode to learn the controls. The game is built with HTML, CSS and JavaScript and is designed to function offline.

## Project features

- Seven-day fictional lunar mission and resource management
- Equipment diagnostics and repair minigames
- Limited Earth Cargo inventory and repair decisions
- NASA DONKI historical-record educational scenarios
- Mission Control, training tutorial and Judge Demo
- English and Vietnamese language options

## NASA data and scientific transparency

The game's NASA DONKI module includes **manually curated historical event records** from NASA CCMC DONKI's May 8–14, 2024 reporting period (report `20240516-7D-001`). These are **not live observations** or proof of a downloaded original NASA API dataset. Resource costs, simulated radiation exposure and health consequences in the game are **educational game models**, not direct NASA lunar measurements. The RadLab section may be reference information only; do not describe it as integrated measurement data without verifying the code.

Official sources to cite in your NASA submission:
- NASA CCMC DONKI — https://ccmc.gsfc.nasa.gov/tools/DONKI/
- NASA Open Science Data Repository — https://osdr.nasa.gov/
- NASA RadLab — https://visualization.osdr.nasa.gov/radlab/gui/data-api/

## How to run

`index.html` is the site entry point. For GitHub Pages, publish branch `main` from `/(root)` in **Settings → Pages**.

## AI and contributors

This project was developed with assistance from Qoder and ChatGPT. Project authors should add the **actual team name, individual contributions, and exact use of AI** before submission. Do not assert unverified contributions or dates.

## Known validation limitations

The seven-day **normal-play win path has not been conclusively verified** in previous testing. A technical test confirmed that the victory screen can display when winning conditions are pre-set, which is not equivalent to a complete ordinary playthrough. Complete gameplay testing and source-data verification are recommended before final submission.
